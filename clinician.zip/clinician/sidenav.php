<?php
// Use centralized session manager
include "../includes/session_manager.php";
requireLogin();

// Include configuration
include "../includes/config.php";
include "../includes/languages.php";

// Get user info from session manager functions
$userrole = getUserRole();
$user_id = getUserId();
$full_name = getUserFullName();
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>EasyFlow-L</title>
<link rel="stylesheet" href="../assets/fontawesome/css/font-awesome.css" type="text/css">
<link rel="stylesheet" href="../assets/fontawesome/css/font-awesome.min.css" type="text/css">
<link rel="stylesheet" href="../assets/fontawesome/css/font-awesome.css" type="text/css">
<link rel="apple-touch-icon" sizes="180x180" href="../assets/favicons/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="../assets/favicons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="../assets/favicons/favicon-16x16.png">
<link rel="manifest" href="../assets/favicons/site.webmanifest">
<link rel="stylesheet" href="../assets/css/bootstrap.min.css" type="text/css">
<link rel="stylesheet" href="../assets/css/sidenav.css" type="text/css">
<?php include "../includes/i18n_script.php"; ?>
<style>

</style>
</head>
<body>

<!-- Timeout Warning Modal -->
<div id="timeout-warning" class="timeout-warning">
    <h4><i class="fa fa-exclamation-triangle"></i> Session Timeout Warning</h4>
    <p>Your session will expire in <span id="countdown">60</span> seconds due to inactivity.</p>
    <button onclick="continueSession()">Continue Session</button>
</div>

<div class="sidenav">
    <h2>
        <i class="fa fa-stethoscope"></i><br>
        Clinical Consultations
    </h2>
    <?php include "../includes/lang_switcher_snippet.php"; ?>

    <!-- Home link - will navigate away from this page -->
    <a href="../dashboard/dashboard.php" class="nav-link home-link">
        <i class="fa fa-home"></i>Home
    </a>
    <a href="../records/dashboard.php" target="contentFrame" class="nav-link" style="background: yellow; color: #000000; margin-top: 10px;">
        <i class="fa fa-pump-medical"></i>Dashboard</a>

    <a href="../appointments/update_appointments.php" target="contentFrame" class="nav-link" style="background: #9EFF9E; color: #000000; margin-top: 10px; margin-bottom: 10px;">
                    <i class="fa fa-stethoscope"></i>Update Appointments</a>
        
    <a href="../clinician/update_dose.php" target="contentFrame" class="nav-link" style="background: yellow; color: #000000;">
            <i class="fa fa-clone"></i>Update dosage</a>
    <a href="../clinician/client_search_consent.php" target="contentFrame" class="nav-link">
        <i class="fa fa-lock"></i>Consent Form 3 E ver 2020</a>
    <!--<a href="../clinician/treatment-old.php" target="contentFrame" class="nav-link"  style="background: yellow; margin-top: 10px; color: #000000;">
        <i class="fa fa-stethoscope"></i>Clinical Follow Up - OLD</a>-->
    <a href="../clinician/search_yellow_card.php" target="contentFrame" class="nav-link" style="background: yellow; margin-top: 10px; color: #000000;">
        <i class="fa fa-card"></i>Clinian Yellow Card</a>
    <a href="../clinician/clinician_follow_up_form.php" target="contentFrame" class="nav-link" style="background: #cff0ce; margin-top: 10px; color: #000000;">
        <i class="fa fa-stethoscope"></i>ART Clinical Follow Up</a>
    <a href="../clinician/clinical_encounter_search.php" target="contentFrame" class="nav-link">
        <i class="fa fa-stethoscope"></i>Initial Clinical Encounter Form</a>
    <a href="../clinician/other_prescriptions.php" target="contentFrame" class="nav-link">
        <i class="fa fa-file"></i>Prescribe other drugs</a>
    <a href="../clinician/search_patients_involuntary.php" target="contentFrame" class="nav-link">
        <i class="fa fa-user-circle"></i>Involuntary Discontinuation</a>
    <a href="../clinician/search_patients_voluntary.php" target="contentFrame" class="nav-link">
        <i class="fa fa-user-circle"></i>Voluntary Discontinuation</a>
    <a href="../referrals/referral_dashboard.php" target="contentFrame" class="nav-link">
            <i class="fa fa-stethoscope"></i>View referrals</a>
    <a href="../patients/view_hiv_positive.php" target="contentFrame"  class="nav-link">
        <i class="fa fa-microchip"></i>HIV Viral Load</a>
    <a href="../clinician/transfer_form_search.php" target="contentFrame" class="nav-link">
        <i class="fa fa-stethoscope"></i>Transfer Form</a>
    <a href="../laboratory/toxicology_results.php" target="contentFrame"  class="nav-link">
        <i class="fa fa-binoculars"></i>Toxicology Results</a>
    <a href="../reports/search_patient_treatment_card_form3c.php" target="contentFrame" class="nav-link">
        <i class="fa fa-users"></i>Form 3C Yellow Card</a>

</div>

<div class="main">
    <div class="content-header">
        <h2>Patient clinical management</h2>
        <div class="user-info">
            <div class="user-details">
                    <?php
                        if (isset($_SESSION['current_facility_name'])) {
                            echo htmlspecialchars($_SESSION['current_facility_name']);
                        } else {
                            echo "No Facility Set";
                        }
                    ?>
                </div>
            <span>Welcome, <strong><?php echo $_SESSION['full_name'] ?? 'User'; ?></strong> (<?php echo $userrole; ?>)</span>
            <span class="current-time">
                <i class="far fa-clock"></i> <span id="current-time"><?php echo date('H:i:s'); ?></span>
            </span>
            <a href="../public/login.php" class="logout-btn">
                <i class="fa fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </div>

    <div class="content-area">
        <iframe name="contentFrame" src="about:blank" style="width: 100%; height: 90vh; border: none; display: none;" id="contentFrame"></iframe>

        <div class="welcome-message" id="welcomeMessage">
            <img src="../assets/images/pt-doctor-removebg-preview.png" width="172" height="116" alt="">
            <h3>Welcome to the integrated patient management system</h3>
            <p>Select an option from the side navigation to access services. Your access level is: <strong><?php echo ucfirst($userrole); ?></strong></p>
            <p>As an <strong><?php echo ucfirst($userrole); ?></strong>, <span style="color: red;">always backup your database on external hard-drive and cloud e.g Google Drive</span></p>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const navLinks = document.querySelectorAll('.nav-link[target="contentFrame"]');
        const contentFrame = document.getElementById('contentFrame');
        const welcomeMessage = document.getElementById('welcomeMessage');

        // Function to update current time
        function updateTime() {
            const now = new Date();
            const timeString = now.toLocaleTimeString();
            document.getElementById('current-time').textContent = timeString;
        }

        // Update time immediately and then every second
        updateTime();
        setInterval(updateTime, 1000);

        // Function to load content into iframe
        function loadContent(url) {
            if (url) {
                contentFrame.style.display = 'block';
                welcomeMessage.style.display = 'none';
                contentFrame.src = url;
            }
        }

        // Add click event listeners to navigation links (excluding Home)
        navLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const url = this.getAttribute('href');

                // Remove active class from all links
                navLinks.forEach(l => l.classList.remove('active'));

                // Add active class to clicked link
                this.classList.add('active');

                // Load content
                loadContent(url);

                // Reset timeout timer on activity
                resetTimer();
            });
        });

        // Handle iframe load event
        contentFrame.addEventListener('load', function() {
            try {
                // Adjust iframe height to content
                const iframeDoc = this.contentDocument || this.contentWindow.document;
                const iframeBody = iframeDoc.body;
                const iframeHtml = iframeDoc.documentElement;

                const height = Math.max(
                    iframeBody.scrollHeight,
                    iframeBody.offsetHeight,
                    iframeHtml.clientHeight,
                    iframeHtml.scrollHeight,
                    iframeHtml.offsetHeight
                );

                this.style.height = height + 'px';
            } catch (e) {
                // Cross-origin frame, can't access contents
                console.log('Cannot adjust iframe height due to cross-origin restrictions');
            }
        });

        // Show welcome message initially
        contentFrame.style.display = 'none';
        welcomeMessage.style.display = 'block';
    });

    // Auto logout after inactivity
    let timeout;
    const warningTime = 60; // Show warning 60 seconds before logout
    const logoutTime = 600; // Logout after 600 seconds (5 minutes)

    function resetTimer() {
        clearTimeout(timeout);

        // Hide warning if visible
        const warningElement = document.getElementById('timeout-warning');
        if (warningElement) {
            warningElement.style.display = 'none';
        }

        // Set new timeout
        timeout = setTimeout(showWarning, (logoutTime - warningTime) * 1000);
    }

    function showWarning() {
        // Show warning
        const warningElement = document.getElementById('timeout-warning');
        if (warningElement) {
            warningElement.style.display = 'block';

            // Start countdown
            let seconds = warningTime;
            const countdownElement = document.getElementById('countdown');
            if (countdownElement) {
                countdownElement.textContent = seconds;

                const countdownInterval = setInterval(() => {
                    seconds--;
                    countdownElement.textContent = seconds;

                    if (seconds <= 0) {
                        clearInterval(countdownInterval);
                        window.location.href = '../public/login.php?timeout=1';
                    }
                }, 1000);
            }

            // Set final logout timeout
            timeout = setTimeout(() => {
                window.location.href = '../public/login.php?timeout=1';
            }, warningTime * 1000);
        }
    }

    function continueSession() {
        // Hide warning
        const warningElement = document.getElementById('timeout-warning');
        if (warningElement) {
            warningElement.style.display = 'none';
        }

        // Reset timer
        resetTimer();

        // Send a request to the server to keep the session alive
        fetch('../includes/keepalive.php')
            .then(response => response.text())
            .then(data => {
                console.log('Session extended');
            })
            .catch(error => {
                console.error('Error extending session:', error);
            });
    }

    // Reset timer on any user activity
    document.addEventListener('mousemove', resetTimer);
    document.addEventListener('keypress', resetTimer);
    document.addEventListener('click', resetTimer);
    document.addEventListener('scroll', resetTimer);

    // Initialize timer
    resetTimer();
</script>
<script>
            // Keep session alive across page navigation
            let sessionKeepAlive = null;

            function startSessionKeepAlive() {
                // Send keep-alive request every 5 minutes
                sessionKeepAlive = setInterval(() => {
                    fetch('../includes/keepalive.php')
                        .then(response => response.text())
                        .then(data => {
                            console.log('Session kept alive');
                        })
                        .catch(error => {
                            console.error('Error keeping session alive:', error);
                        });
                }, 300000); // 5 minutes
            }

            // Stop keep-alive when leaving page
            function stopSessionKeepAlive() {
                if (sessionKeepAlive) {
                    clearInterval(sessionKeepAlive);
                    sessionKeepAlive = null;
                }
            }

            // Start when page loads
            document.addEventListener('DOMContentLoaded', function() {
                startSessionKeepAlive();
            });

            // Clean up before page unload
            window.addEventListener('beforeunload', stopSessionKeepAlive);

            // Reset timeout on user activity
            ['click', 'mousemove', 'keypress', 'scroll', 'touchstart'].forEach(event => {
                document.addEventListener(event, function() {
                    // Send activity ping
                    fetch('../includes/keepalive.php?activity=1')
                        .then(response => response.text())
                        .then(data => {
                            console.log('Activity recorded');
                        });
                });
            });
    </script>

</body>
</html>